import os
import json
import logging
import requests 

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def lambda_handler(event, context):
    city_name = event["currentIntent"]["slots"]["City"]
    
    req_url = "https://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}".format(city_name, os.environ("WEATHER_API"))
    params = {
        'q':city_name,
        'appid':os.environ("WEATHER_API")
    }
    response = requests.get("https://api.openweathermap.org/data/2.5/weather", params)
    logger.debug(response)
    return {
        "sessionAttributes": event["sessionAttributes"],
        "dialogAction":{
            "type":"Close",
            "fulfillmentState":"Fulfilled",
            "message":{
                "contentType":"PlainText",
                "content":city_name
            }
        }
    }